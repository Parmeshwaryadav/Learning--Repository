// Var and Let
// Global
// local (Script)
// local (Script)
// Hoisting
// Execution Content
// Call Stack
// Clouser
// sum();
// sub();
// console.log(a);
// var a = 10;

// // Message i shared with you on whatsapp
// function sum() {
//   var num1 = 10;
//   var num2 = 20;
//   console.log(num1 + num2);
// }

// function sub() {
//   var num1 = 10;
//   var num2 = 20;
//   console.log(num1 - num2);
// }

// function sum() {
//   var a = 10;
//   function sub(paramter) {
//     function mult() {
//       console.log(a);
//     }
//   }
//   sub(a);
// }
// sum();

// Home Work

//  var sum = function(){

// }

// let sub = () =>{

// }

// Promise API wala part in Next saturday class
// Working of HOF and Callback in Next Saturday

// HOF
// Other Function as Parameter
// Return A Function

// Callback
//A function which can be passed as parameter to other function

// set timeout

// setTimeout(() => {
//   console.log("hello Duniya");
// }, 3000);

// setInterval(() => {
//   console.log("Refresh");
// }, 1000);

// Functional Programming
// So that we dont have to write regular loop and function

// Foreach

// const arr = [
//   "Shiva",
//   "Anurag",
//   "Yuvrah",
//   "Chiranjeev",
//   "VYOM",
//   "Kaushik",
//   "Azhar",
// ];
// IMP
// arr.forEach((val) => {
//   console.log(val);
// });

// IMP
// Map, Filter, Reduce

// const number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 16];
// const num = number.map((val) => val * 3.14);
// console.log(num);

// Filter

const countries = [
  "Albania",
  "Bolivia",
  "Canada",
  "Denmark",
  "Ethiopia",
  "Finland",
  "Germany",
  "Hungary",
  "Ireland",
  "Indialand",
  "Japan",
  "Kenyaland",
  "pakistanland",
];

// const count = countries.filter((country) => country.includes("land"));
// console.log(count);
// Reduce
